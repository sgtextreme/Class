require 'test_helper'

class PostsubTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
