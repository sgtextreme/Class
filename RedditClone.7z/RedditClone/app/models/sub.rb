class Sub < ApplicationRecord

  validates :title, :description, :moderator_id, presence: true
  belongs_to :moderator

  has_many :posts
  has_many :postsubs
  

end
