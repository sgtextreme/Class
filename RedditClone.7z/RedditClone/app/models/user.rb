class User < ApplicationRecord

validates :username, :password_digest, presence: true
validates :password, length:{minimum: 7, allow_nil: true }


  def password=(password)

    @password = password

    password_digest = BCRypt::Password.urlsafe_base64

  end

  def is_password?

    BCrypt::Password.new(password_digest).is_password(password)

  end


  def ensure_session_token!

    self.session_token||=SecureRandom.urlsafe_base64

  end


  def find_by_credentials(username, password)

    user = User.find_by(username: username)
    user && user.is_password(password) ? user : nil

  end
end
