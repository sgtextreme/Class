class SubsController < ApplicationController

before_action :require_login

  def new
    @link.Link.new
  end

  def create
    @sub = Sub.new(sub_params)
    if @sub.save
      redirect_to subs_url
    else
      flash[:errors] = @sub.errors.full_messages
    end

  end

  def edit
    @sub = Sub.find(parasm[:id])
  end

  def update

    @sub = Sub.fing(params[:id])
    if @sub.update(sub_params)
      redirect_to #pending
    else
      flash[:errors] = @sub.errors.full_messages
      render :edit

    end

  end



  def show

    @sub = Sub.find(params[:id])
  end

  def destroy
    @link = Link.find(params[:id])
  end

  def sub_params

    params.require(:moderator_id).permit(:title, :description)

  end
end
