class PostsController < ApplicationController
  def new
  end

  def create
    @post = Post.new(post_params)
    if @post.save!
      redirect_to #pending
    else
      flash[:errors] = @post.errors.full_messages
    end

  end

  def edit
    @post = Post.find(params[:id])
  end

  def update
    @post = Post.find(params[:id])
    if @post.update(post_params)
      redirect_to post_url(@post)
    else
      flash.now[:errors] = @post.errors.full_messagess

  end

  def show
    @post = Post.find(params[:id])
  end

  def index
  end

  def destroy
    @post = Post.find(params[:id])

  end

  def post_params

    params.require(:post).permit(:title, :url, :content, :sub, :user_id)

  end
end
