Rails.application.routes.draw do
  get 'comments/new'

  get 'comments/create'

  get 'comments/edit'

  get 'comments/update'

  get 'comments/show'

  get 'comments/index'

  get 'comments/destroy'

  get 'posts/new'

  get 'posts/create'

  get 'posts/edit'

  get 'posts/update'

  get 'posts/show'

  get 'posts/index'

  get 'posts/destroy'

  get 'subs/new'

  get 'subs/create'

  get 'subs/edit'

  get 'subs/update'

  get 'subs/index'

  get 'subs/show'

  get 'subs/destroy'

  get 'session/new'

  get 'session/create'

  get 'session/destroy'

  get 'users/new'

  get 'users/create'

  get 'users/edit'

  get 'users/update'

  get 'users/show'

  get 'users/index'

  get 'users/destroy'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
